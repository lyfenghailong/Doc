package com.fhl.gmdemo;

import java.io.IOException;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;

import android.os.Bundle;
import android.os.Handler;
import android.util.Log;
import android.view.Menu;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;

import com.google.android.maps.MapActivity;
import com.google.android.maps.MapView;

public class GoogleMapDemoActivity extends MapActivity implements OnClickListener 
{
    private ItemizedOverlayDemo items = null;
    private static final String TAG = "GoogleMapDemoActivity";
    private MapView m_mapView = null;
    private MyLoctionUtil locationUtil = null;
    private Button btnGetLine = null;
    Handler handler = new Handler()
    {
        public void handleMessage(android.os.Message msg) 
        {
            switch(msg.what)
            {
            case 1:
                drawMyLocation();
                break;
            }
        };
    };
    /** Called when the activity is first created. */
    @Override
    public void onCreate(Bundle savedInstanceState) 
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.main);
        initialize();
    }
    
    private void initialize()
    {
        m_mapView = (MapView)findViewById(R.id.gooleMapView);
        m_mapView.setBuiltInZoomControls(true);
      //设置为交通模式  
        m_mapView.setTraffic(true);  
      //设置为卫星模式  
       // m_mapView.setSatellite(true);   
      //设置为街景模式  
      //mMapView.setStreetView(false);
        
        btnGetLine = (Button)findViewById(R.id.btnGetLine);
        btnGetLine.setOnClickListener(this);
        
        locationUtil = new MyLoctionUtil(this, m_mapView);
        locationUtil.runOnFirstFix(new Runnable()
        {
            @Override
            public void run()
            {
                handler.obtainMessage(1).sendToTarget();
            }
        });
    }
    
    @Override
    protected void onResume()
    {
        if (null != locationUtil)
        {
            locationUtil.enableMyLocation();
            locationUtil.enableCompass();
        }
        super.onResume();
    }
    
    @Override
    protected void onPause()
    {
        if (null != locationUtil)
        {
            locationUtil.disableMyLocation();
            locationUtil.disableCompass();
        }
        super.onPause();
    }
    
    @Override
    protected boolean isRouteDisplayed()
    {
        // TODO Auto-generated method stub
        return false;
    }
    
    @Override
    public boolean onMenuOpened(int featureId, Menu menu)
    {
        // TODO Auto-generated method stub
        return super.onMenuOpened(featureId, menu);
    }
    
    private void drawMyLocation()
    {
        Log.d(TAG, "begin to draw ");
        m_mapView.getOverlays().add(locationUtil);
        m_mapView.getController().animateTo(locationUtil.getMyLocation());
        Log.d(TAG, "My location :" + locationUtil.getMyLocation());
    }
    
    @Override
    public void onClick(View v)
    {
        switch(v.getId())
        {
        case R.id.btnGetLine:
            onBtnGetLineClick();
            break;
        }
    }
    
    /**
     * 获取线路信息
     */
    private void onBtnGetLineClick()
    {
        String url = "http://maps.googleapis.com/maps/api/directions/json?origin=Adelaide," +
                        "SA&destination=Adelaide," +
                        "SA&waypoints=optimize:true|Barossa+Valley," +
                        "SA|Clare,SA|Connawarra,SA|McLaren+Vale,SA&sensor=false";
        URL myURL;
        try
        {
            myURL = new URL(url);
            HttpURLConnection conn = (HttpURLConnection) myURL.getContent();
            conn.setDoInput(true);
            conn.connect();
            InputStream in = conn.getInputStream();
        } catch (IOException e)
        {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }
    }
}