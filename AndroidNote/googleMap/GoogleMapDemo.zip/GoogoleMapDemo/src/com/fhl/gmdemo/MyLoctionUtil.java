package com.fhl.gmdemo;

import android.app.AlertDialog;
import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Point;

import com.google.android.maps.GeoPoint;
import com.google.android.maps.MapView;
import com.google.android.maps.MyLocationOverlay;

public class MyLoctionUtil extends MyLocationOverlay
{
    private  GeoPoint location1 = null;
    private Context context  = null;
    
    public MyLoctionUtil(Context context, MapView mapView)
    {
        super(context, mapView);
        this.context = context;
        // TODO Auto-generated constructor stub
    }
    
    @Override
    public synchronized boolean draw(Canvas canvas, MapView mapView,
            boolean shadow, long when)
    {
        super.draw(canvas, mapView, shadow);
        Bitmap bmp = BitmapFactory.decodeResource(context.getResources(),R.drawable.ic_launcher);
        if (null == location1)
        {
            location1 = getMyLocation();
        }
        Paint paint = new Paint();  
        Point myScreenCoords = new Point();  
        // 将经纬度转换成实际屏幕坐标  
        mapView.getProjection().toPixels(location1,myScreenCoords);  
        paint.setStrokeWidth(1);  
        paint.setARGB(255, 255, 0, 0);  
        paint.setStyle(Paint.Style.STROKE);  
        
        canvas.drawBitmap(bmp,myScreenCoords.x,myScreenCoords.y,paint);  
        canvas.drawText("我的位置",myScreenCoords.x, myScreenCoords.y,paint); 
        
        return true; 
    }

    /**
     * 处理mark 的点击事件。
     */
    @Override
    protected boolean dispatchTap()
    {
        if (null == context)
        {
            return false;
        }
        AlertDialog dialog = new AlertDialog.Builder(context).create();
        dialog.setTitle("我的位置：");
        dialog.setMessage("我所在的地理坐标：" + location1);
        dialog.show();
        return true;
    }

    
}
