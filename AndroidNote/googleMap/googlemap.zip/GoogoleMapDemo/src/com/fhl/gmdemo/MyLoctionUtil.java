package com.fhl.gmdemo;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Point;
import android.location.Location;
import android.util.Log;

import com.google.android.maps.GeoPoint;
import com.google.android.maps.MapView;
import com.google.android.maps.MyLocationOverlay;

public class MyLoctionUtil extends MyLocationOverlay
{
    private  GeoPoint location1 = null;
    private Context context  = null;
    private MapView mapView = null;
    String str = "利达智通";
    public MyLoctionUtil(Context context, MapView mapView)
    {
        super(context, mapView);
        this.mapView = mapView;
        this.context = context;
        // TODO Auto-generated constructor stub
    }
    
    @Override
    public synchronized boolean draw(Canvas canvas, MapView mapView,
            boolean shadow, long when)
    {
        super.draw(canvas, mapView, shadow);
        Bitmap bmp = BitmapFactory.decodeResource(context.getResources(),R.drawable.ic_launcher);
        if (null == location1)
        {
            location1 = getMyLocation();
        }
        Paint paint = new Paint();  
        Point myScreenCoords = new Point();  
        // 将经纬度转换成实际屏幕坐标  
        mapView.getProjection().toPixels(location1,myScreenCoords);  
        paint.setStrokeWidth(1);  
        paint.setARGB(255, 255, 0, 0);  
        paint.setStyle(Paint.Style.STROKE);  
         
        canvas.drawBitmap(bmp,myScreenCoords.x,myScreenCoords.y,paint);  
        canvas.drawText(str,myScreenCoords.x, myScreenCoords.y,paint); 
        if (null != mapView)
        {
            mapView.getController().animateTo(location1);
        }
        return true; 
    }
    
    @Override
    protected void drawMyLocation(Canvas canvas, MapView mapView,
            Location lastFix, GeoPoint myLocation, long when)
    {
        // TODO Auto-generated method stub
        super.drawMyLocation(canvas, mapView, lastFix, myLocation, when);
    }
    
    public void setGeoPoint(GeoPoint point)
    {
        location1 = point;
    }
    
    @Override
    public synchronized void onLocationChanged(Location location)
    {
        
        location1 = new GeoPoint((int)(location.getLatitude()*1E6),(int)(location.getLongitude()*1E6));
        str = str + "*";
        super.onLocationChanged(location);
    }
    
}
