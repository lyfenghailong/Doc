package com.fhl.gmdemo;

import java.util.ArrayList;

import android.app.AlertDialog;
import android.content.Context;
import android.graphics.drawable.Drawable;

import com.google.android.maps.ItemizedOverlay;
import com.google.android.maps.OverlayItem;

public class ItemizedOverlayDemo extends ItemizedOverlay<OverlayItem>
{
    private ArrayList<OverlayItem> overlayItems = new ArrayList<OverlayItem>();
    private Context m_context = null;
    

    public ItemizedOverlayDemo(Drawable defaultMarker, Context context)
    {
        super(boundCenterBottom(defaultMarker));
        
        m_context = context;
    }
    
    public ArrayList<OverlayItem> getOverlayItems()
    {
        return overlayItems;
    }
    
    public void addOverlayItem(OverlayItem overlayItem)
    {
        overlayItems.add(overlayItem);
        populate();
    }

    @Override
    protected OverlayItem createItem(int i)
    {
        // TODO Auto-generated method stub
        return overlayItems.get(i);
    }

    @Override
    public int size()
    {
        // TODO Auto-generated method stub
        return overlayItems.size();
    }
    
    @Override
    protected boolean onTap(int index)
    {
        if (null == m_context)
        {
            return false;
        }
        OverlayItem item = overlayItems.get(index);
        AlertDialog.Builder dialog = new AlertDialog.Builder(m_context);
        dialog.setTitle(item.getTitle());
        dialog.setMessage(item.getSnippet());
        dialog.show();
        return true;
    }
}
