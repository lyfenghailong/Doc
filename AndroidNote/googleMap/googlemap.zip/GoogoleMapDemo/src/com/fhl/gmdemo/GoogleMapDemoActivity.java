package com.fhl.gmdemo;

import android.os.Bundle;
import android.os.Handler;
import android.util.Log;
import android.view.Menu;

import com.google.android.maps.MapActivity;
import com.google.android.maps.MapView;

public class GoogleMapDemoActivity extends MapActivity 
{
    ItemizedOverlayDemo items = null;
    private static final String TAG = "GoogleMapDemoActivity";
    private MapView m_mapView = null;
    private MyLoctionUtil locationUtil = null;
    Handler handler = new Handler()
    {
        public void handleMessage(android.os.Message msg) 
        {
            switch(msg.what)
            {
            case 1:
                drawMyLocation();
                break;
            }
        };
    };
    /** Called when the activity is first created. */
    @Override
    public void onCreate(Bundle savedInstanceState) 
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.main);
        initialize();
    }
    
    private void initialize()
    {
        m_mapView = (MapView)findViewById(R.id.gooleMapView);
        m_mapView.setBuiltInZoomControls(true);
      //设置为交通模式  
        m_mapView.setTraffic(true);  
      //设置为卫星模式  
       // m_mapView.setSatellite(true);   
      //设置为街景模式  
      //mMapView.setStreetView(false);
        
        locationUtil = new MyLoctionUtil(this, m_mapView);
        locationUtil.runOnFirstFix(new Runnable()
        {
            @Override
            public void run()
            {
                handler.obtainMessage(1).sendToTarget();
            }
        });
    }
    @Override
    protected void onResume()
    {
        if (null != locationUtil)
        {
            locationUtil.enableMyLocation();
            locationUtil.enableCompass();
        }
        super.onResume();
    }
    
    @Override
    protected void onPause()
    {
        if (null != locationUtil)
        {
            locationUtil.disableMyLocation();
            locationUtil.disableCompass();
        }
        super.onPause();
    }
    @Override
    protected boolean isRouteDisplayed()
    {
        // TODO Auto-generated method stub
        return false;
    }
    @Override
    public boolean onMenuOpened(int featureId, Menu menu)
    {
        // TODO Auto-generated method stub
        return super.onMenuOpened(featureId, menu);
    }
    private void drawMyLocation()
    {
        Log.d(TAG, "begin to draw ");
        m_mapView.getOverlays().add(locationUtil);
        Log.d(TAG, "My location :" + locationUtil.getMyLocation());
    }
}